"""
Program: VivasKarlFinalProject.py
Author: Karl Mathew Vivas
Last date modified: 12/12/23
The purpose of this program is to serve as a way for people to find a way to lose, gain, or maintain weight based off their height, weight, and activity level.
"""
import tkinter as tk
from tkinter import messagebox

class WorkoutRecommendationApp:
    def __init__(self, master):
        self.master = master
        master.title("Workout Recommendation App")

        # Create labels
        self.label_weight = tk.Label(master, text="Enter Weight (lbs):")
        self.label_height = tk.Label(master, text="Enter Height:")
        self.label_feet = tk.Label(master, text="Feet:")
        self.label_inches = tk.Label(master, text="Inches:")
        self.label_activity_level = tk.Label(master, text="Select Activity Level:")
        self.label_weight_goal = tk.Label(master, text="Select Weight Goal:")

        # Create entry widgets
        self.entry_weight = tk.Entry(master)
        self.entry_feet = tk.Entry(master)
        self.entry_inches = tk.Entry(master)

        # Create dropdown menus
        self.activity_levels = ["Barely Active", "Lightly Active", "Moderately Active", "Very Active"]
        self.activity_level_var = tk.StringVar(master)
        self.activity_level_var.set(self.activity_levels[0])
        self.activity_level_dropdown = tk.OptionMenu(master, self.activity_level_var, *self.activity_levels)

        self.weight_goals = ["Lose Weight", "Maintain Weight", "Gain Weight"]
        self.weight_goal_var = tk.StringVar(master)
        self.weight_goal_var.set(self.weight_goals[0])
        self.weight_goal_dropdown = tk.OptionMenu(master, self.weight_goal_var, *self.weight_goals)

        # Create buttons
        self.button_generate = tk.Button(master, text="Generate Workout", command=self.generate_workout)
        self.button_exit = tk.Button(master, text="Exit", command=self.exit_app)
        self.button_reset = tk.Button(master, text="Reset", command=self.reset_fields)

        # Pack widgets
        self.label_weight.grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
        self.entry_weight.grid(row=0, column=1, padx=10, pady=5, sticky=tk.W)

        self.label_height.grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        self.label_feet.grid(row=1, column=1, padx=10, pady=5, sticky=tk.W)
        self.entry_feet.grid(row=1, column=2, padx=10, pady=5, sticky=tk.W)
        self.label_inches.grid(row=1, column=3, padx=10, pady=5, sticky=tk.W)
        self.entry_inches.grid(row=1, column=4, padx=10, pady=5, sticky=tk.W)

        self.label_activity_level.grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
        self.activity_level_dropdown.grid(row=2, column=1, padx=10, pady=5, sticky=tk.W)

        self.label_weight_goal.grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        self.weight_goal_dropdown.grid(row=3, column=1, padx=10, pady=5, sticky=tk.W)

        self.button_generate.grid(row=4, column=0, padx=10, pady=5, sticky=tk.W)
        self.button_exit.grid(row=4, column=1, padx=10, pady=5, sticky=tk.W)
        self.button_reset.grid(row=4, column=2, padx=10, pady=5, sticky=tk.W)

    def generate_workout(self):
        # Get user inputs
        try:
            weight = float(self.entry_weight.get())
            feet = float(self.entry_feet.get())
            inches = float(self.entry_inches.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid input for weight, height, or inches. Please enter valid numbers.")
            return

        # Convert height to inches
        height = (feet * 12) + inches

        activity_level = self.activity_level_var.get()
        weight_goal = self.weight_goal_var.get()

        # Sample workout recommendation logic (customize as needed)
        workout_intensity = {
            "Barely Active": "Light",
            "Lightly Active": "Moderate",
            "Moderately Active": "Intense",
            "Very Active": "High Intensity"
        }

        # Determine workout intensity based on activity level
        intensity = workout_intensity.get(activity_level, "Unknown")

        # Generate workout recommendation based on weight goal
        if weight_goal == "Lose Weight":
            recommendation = f"For weight loss, consider a combination of cardio exercises and strength training at {intensity} intensity."
        elif weight_goal == "Maintain Weight":
            recommendation = f"To maintain weight, focus on a balanced mix of cardio and strength training at {intensity} intensity."
        elif weight_goal == "Gain Weight":
            recommendation = f"For weight gain, include more strength training exercises and consume a calorie surplus at {intensity} intensity."
        else:
            recommendation = "Invalid weight goal."

        # Display workout recommendation
        messagebox.showinfo("Workout Recommendation", recommendation)

        # Example: Display a message with the selected weight goal
        selected_goal = self.weight_goal_var.get()
        messagebox.showinfo("Workout Recommendation", f"Selected Weight Goal: {selected_goal}")

    def exit_app(self):
        # Callback function for the Exit button
        self.master.destroy()

    def reset_fields(self):
        # Reset all entry fields and dropdowns
        self.entry_weight.delete(0, tk.END)
        self.entry_feet.delete(0, tk.END)
        self.entry_inches.delete(0, tk.END)
        self.activity_level_var.set(self.activity_levels[0])
        self.weight_goal_var.set(self.weight_goals[0])


if __name__ == "__main__":
    root = tk.Tk()
    app = WorkoutRecommendationApp(root)
    root.mainloop()